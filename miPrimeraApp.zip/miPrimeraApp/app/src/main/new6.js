async function guardarProducto() {
    // 1. Capturar los valores de los inputsconst nombre = document.getElementById('nombre').value;
    const costo = parseFloat(document.getElementById('costo').value);
    const precio_venta = parseFloat(document.getElementById('precio_venta').value);
    const stock = parseInt(document.getElementById('stock').value);

    // 2. Punto 3.b: Cálculo de ganancia
    // Fórmula: ((Precio - Costo) / Costo) * 100
    const porcentaje_ganancia = ((precio_venta - costo) / costo) * 100;

    // 3. Crear el objeto JSON que se enviará a CouchDB
    const producto = {
        nombre: nombre,
        costo: costo,               // Punto 3.a
        precio_venta: precio_venta,
        porcentaje_ganancia: porcentaje_ganancia.toFixed(2), // Resultado del cálculo
        stock: stock                // Punto 4.a
    };

    // 4. Punto 3.c y 4.b: Guardar en la base de datos (CouchDB)
    try {
        const response = await fetch('http://admin:password@192.168.56.1:5984/miguelsaravia', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(producto)
        });

        if (response.ok) {
            alert("Producto guardado exitosamente con costo, ganancia y stock.");
        }
    } catch (error) {
        console.error("Error al conectar con CouchDB:", error);
    }
}
