function (doc) {
  // Verificamos que el documento tenga los campos necesarios
  if (doc.costo && doc.precio_venta && doc.stock !== undefined) {
    
    // Cálculo de ganancia (Punto 3.b)
    var ganancia = ((doc.precio_venta - doc.costo) / doc.costo) * 100;
    
    // Emitimos los datos incluyendo el stock (Punto 4)
    emit(doc.nombre, {
      "Costo": doc.costo,
      "Precio Venta": doc.precio_venta,
      "Ganancia %": ganancia.toFixed(2) + "%",
      "Existencia (Stock)": doc.stock
    });
  }
}