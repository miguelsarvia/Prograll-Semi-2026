function (doc) {
  // Verificamos que existan los campos para evitar errores
  if (doc.costo && doc.precio_venta) {
    
    // b. Cálculo de ganancia
    var calculo = ((doc.precio_venta - doc.costo) / doc.costo) * 100;
    
    // Mostramos el resultado
    emit(doc.nombre, {
      "Costo": doc.costo,
      "Precio al Público": doc.precio_venta,
      "Porcentaje de Ganancia": calculo.toFixed(2) + "%"
    });
  }
}