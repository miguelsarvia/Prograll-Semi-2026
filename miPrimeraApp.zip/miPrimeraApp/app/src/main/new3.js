    const nano = require('nano')('http://admin:password@localhost:5984');
    const db = nano.db.use('nombre_de_tu_db');

    // Ejemplo: Insertar un documento
    async function insertDoc() {
      const response = await db.insert({ nombre: "Ejemplo", tipo: "Prueba" });
      console.log(response);
    }
    