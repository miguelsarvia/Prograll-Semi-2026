const nano = require('nano')('http://admin:password@localhost:5984');
const db = nano.db.use('inventario');

async function guardarProducto() {
    try {
        // Intentamos insertar o actualizar el documento
        const response = await db.insert(producto);
        console.log("Guardado exitosamente:", response);
    } catch (error) {
        console.error("Error al guardar:", error);
    }
}

guardarProducto();