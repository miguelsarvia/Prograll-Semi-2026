// 1. Definimos los datos base
let producto = {_id: "prod_001", // ID único del documento
    nombre: "Laptop Pro",
    precio_venta: 1200, // Precio al público
    costo: 800          // a. Agregar el campo costo
};

// 2. b. Cálculo de ganancia
// Calculamos qué porcentaje del costo representa la utilidad
let ganancia = ((producto.precio_venta - producto.costo) / producto.costo) * 100;
producto.porcentaje_ganancia = ganancia; // Agregamos el resultado al objeto

console.log(`El producto tiene una ganancia del ${ganancia}%`);